package org.mishka.testjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}

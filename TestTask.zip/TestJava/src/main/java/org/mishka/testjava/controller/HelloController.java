package org.mishka.testjava.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/hello")
public class HelloController {

    @CrossOrigin
    @GetMapping
    public String get(@RequestParam(name = "number") Integer number) {
        return "{\"msg\": \"Your circle radius is: " + circleCalc(number) + "\"}";
    }

    private int pow(int a) {
        return a*a;
    }

    private float circleCalc(int number) {
        return (float) 3.1415 * pow(number);
    }
}

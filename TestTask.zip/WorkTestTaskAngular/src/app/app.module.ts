import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShapeFormComponent } from './shape-form.component';
import { AppComponent } from './app.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {HelloService} from './hello.service';

@NgModule({
  declarations: [
    AppComponent,
    ShapeFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient, HelloService],
  bootstrap: [AppComponent]
})
export class AppModule { }

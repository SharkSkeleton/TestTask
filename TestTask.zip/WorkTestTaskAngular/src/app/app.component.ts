import { Component } from '@angular/core';

const message1 = 'Your area is: ';

@Component({
  selector: 'app-root',
  template: '<shape-form></shape-form>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'WorkTestTask';
}

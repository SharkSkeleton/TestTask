import {Component, OnInit} from '@angular/core';
import { Shape } from './shape';
import {HttpClient} from '@angular/common/http';
import {HelloService} from './hello.service';


@Component ({
  // tslint:disable-next-line:component-selector
  selector: 'shape-form',
  templateUrl: './shape-form.component.html'
})

export class ShapeFormComponent implements OnInit {
  model = new Shape('Circle', 5);
  message: string;

  btnClick() {
    this.helloservice.getNumber(this.model.shapeSize).subscribe((result: any) => this.message = result.msg);
  }

  ngOnInit(): void {
    this.helloservice.getNumber(this.model.shapeSize).subscribe((result: any) => this.message = result.msg);
  }

  constructor(private helloservice: HelloService) { }
}


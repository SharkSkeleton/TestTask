export class Shape {
  constructor(
    public shapeName: string,
    public shapeSize: number
  ) {  }
}
